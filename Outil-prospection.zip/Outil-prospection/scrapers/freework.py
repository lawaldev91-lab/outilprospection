"""
Scraper Free-work.com — scraping HTML public
"""
import requests
import re
import time
from bs4 import BeautifulSoup
from config import REQUEST_TIMEOUT, REQUEST_DELAY, INTENT_KEYWORDS_FR

URL = "https://www.freelance-info.fr/missions"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9",
}

def fetch() -> list[dict]:
    """Scrape les missions freelance sur Free-work / Freelance-info."""
    results = []
    seen_urls = set()

    try:
        resp = requests.get(URL, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        if resp.status_code != 200:
            print(f"  [Free-work] HTTP {resp.status_code}")
            return results

        soup = BeautifulSoup(resp.text, "html.parser")

        # Recherche de tous les liens vers des missions
        links = soup.find_all("a", href=re.compile(r"/fr/tech-it/job-mission/|/missions/"))

        for link in links:
            href = link["href"]
            if href.startswith("/"):
                href = "https://www.free-work.com" + href
            
            if href in seen_urls:
                continue
            seen_urls.add(href)

            # On remonte au conteneur parent pour avoir tout le texte descriptif
            parent = link.find_parent("div") or link.find_parent("article") or link.find_parent("li")
            if not parent:
                continue
            
            text_content = parent.get_text(" ", strip=True)
            text_lower = text_content.lower()

            # Ne garder que les missions spécifiquement annoncées comme Freelance
            if "freelance" not in text_lower and "indépendant" not in text_lower:
                continue

            title_elem = parent.find(["h1", "h2", "h3", "h4"])
            title = title_elem.get_text(strip=True) if title_elem else text_content[:100]

            results.append({
                "id": f"fw_{hash(href)}",
                "title": title,
                "body": text_content[:400],
                "url": href,
                "source": "Free-work",
                "date": "",
                "contact": _extract_contact(text_content),
                # Signal fort injecté car c'est une plateforme spécialisée dans les demandes de freelances
                "raw_text": text_lower + " mission freelance projet budget devis",
            })

            # Limiter à 20 résultats max
            if len(results) >= 20:
                break

        time.sleep(REQUEST_DELAY)

    except requests.RequestException as e:
        print(f"  [Free-work] Erreur: {e}")

    return results


def _extract_contact(text: str) -> str:
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}", text)
    if email_match:
        return email_match.group(0)
    return ""
