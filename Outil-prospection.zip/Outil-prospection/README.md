# 🔍 Outil de Prospection

Outil local de veille qui cherche automatiquement des demandes de prestataires sur des sources publiques, dans 6 catégories : **Site Web · Chatbot · Automatisation · Modélisation 3D · Montage Vidéo · Réseaux Sociaux**.

---

## ⚡ Installation rapide

### 1. Installer les dépendances Python

```bash
cd ~/Desktop/Outil-prospection
python3 -m pip install -r requirements.txt
```

### 2. Configurer Reddit (5 min, gratuit)

1. Allez sur **https://www.reddit.com/prefs/apps**
2. Cliquez **"Create App"**
3. Remplissez :
   - **Name** : `prospection-tool`
   - **Type** : cochez **script**
   - **Redirect URI** : `http://localhost:8080`
4. Notez votre `client_id` (sous le nom) et `client_secret`
5. Ouvrez `config.py` et remplacez :
   ```python
   REDDIT_CLIENT_ID = "VOTRE_CLIENT_ID"
   REDDIT_CLIENT_SECRET = "VOTRE_CLIENT_SECRET"
   ```

> Si vous ne souhaitez pas utiliser Reddit, mettez `REDDIT_ENABLED = False` dans `config.py`.

---

## 🚀 Lancement

```bash
python main.py
```

Le rapport HTML s'ouvre automatiquement dans votre navigateur.

---

## 📁 Structure des fichiers

```
Outil-prospection/
├── main.py              ← Point d'entrée (à lancer)
├── config.py            ← Configuration : sources, mots-clés, seuils
├── classifier.py        ← Scoring et classification par catégorie
├── report.py            ← Générateur de rapport HTML
├── scrapers/
│   ├── hackernews.py    ← Hacker News (API Algolia publique)
│   ├── reddit.py        ← Reddit (API officielle)
│   ├── devto.py         ← dev.to (API JSON publique)
│   ├── malt.py          ← Malt.fr (scraping HTML public)
│   └── indiehackers.py  ← IndieHackers (scraping HTML public)
└── results/
    ├── report_YYYY-MM-DD.html  ← Rapport du jour
    └── YYYY-MM-DD.json         ← Données brutes (historique)
```

---

## ⚙️ Personnalisation (`config.py`)

| Paramètre | Rôle |
|---|---|
| `SOURCES` | Activer/désactiver chaque source |
| `RELEVANCE_THRESHOLD` | Score minimum pour apparaître (défaut: 3) |
| `HN_DAYS_BACK` | Fenêtre temporelle Hacker News (défaut: 7 jours) |
| `REDDIT_POST_LIMIT` | Posts analysés par subreddit (défaut: 50) |
| `INTENT_KEYWORDS_FR` | Mots-clés de détection d'intention |
| `CATEGORIES` | Catégories et leurs mots-clés associés |

---

## 📊 Rapport HTML

Le rapport généré dans `results/` offre :
- **Filtres** par catégorie et par source
- **Tri** par score de pertinence ou date
- **Recherche** en temps réel
- **Score /10** par résultat
- **Export CSV** en un clic
- Lien direct vers chaque publication source

---

## 🔒 Légalité

Toutes les sources utilisées sont :
- ✅ Accessibles publiquement (sans login)
- ✅ Interrogées via API officielle ou scraping HTML respectueux
- ✅ Respectent le protocole `robots.txt`
- ✅ Avec délai entre requêtes (throttling)

Sources : **Hacker News** (API Algolia), **Reddit** (API officielle OAuth2), **dev.to** (API publique), **Malt.fr** et **IndieHackers** (scraping HTML public).
